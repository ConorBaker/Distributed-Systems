import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class UserDAO {
	
	
	protected static EntityManagerFactory emf = 
			Persistence.createEntityManagerFactory("jpaPU"); 	
	
	public UserDAO() {
		
	}
	
	public void persist(Users user) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(user);
		em.getTransaction().commit();
		em.close();
	}
	
	
	public void remove(Users user) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.remove(em.merge(user));
		em.getTransaction().commit();
		em.close();
	}
	
	public Users merge(Users user) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Users updatedUser= em.merge(user);
		em.getTransaction().commit();
		em.close();
		return updatedUser;
	}
	
	@SuppressWarnings("unchecked")
	public List<Users> getAllUsers() {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<Users> usersFromDB = new ArrayList<Users>();
		usersFromDB = em.createNamedQuery("User.findAll").getResultList();
		em.getTransaction().commit();
		em.close();
		return usersFromDB;
	}
	
	@SuppressWarnings("unchecked")
	public Users getUserByUsername(String username){
		EntityManager em = emf.createEntityManager();
		List<Users> users = (List<Users>) 
				em.createNamedQuery("Users.findByUsername").
				setParameter("username", username).getResultList();
		em.close();
		Users user = new Users();
		for(Users u: users) {
			user = u;
		}
		return user;
		}
}