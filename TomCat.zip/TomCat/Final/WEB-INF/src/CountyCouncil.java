import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.xml.bind.annotation.XmlRootElement;

@NamedQueries({
@NamedQuery(name="CountyCouncil.findAll", query="select o from CountyCouncil o"), 
@NamedQuery(name = "CountyCouncil.findByName", query = "select o from CountyCouncil o where o.name=:name"),
})
@XmlRootElement
@Entity
public class CountyCouncil {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String name;
	
	@OneToMany(fetch = FetchType.EAGER)
	private List<Park> parks = new ArrayList<Park>();
	
	public CountyCouncil(String name, List<Park> parks) {
		this.name = name;
		this.parks = parks;
	}
	
	public CountyCouncil() {
	
	}
	

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the items
	 */
	public List<Park> getParks() {
		return parks;
	}

	/**
	 * @param items the items to set
	 */
	public void setParks(List<Park> parks) {
		this.parks = parks;
	}
	
	public void addPark(Park park) {
		this.parks.add(park);
	}
	
	public void removcPark(Park park) {
		this.parks.remove(park);
	}
	

}
