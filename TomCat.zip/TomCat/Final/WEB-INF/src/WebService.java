
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;

import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/ParkWebService")
public class WebService {

	@POST
	@Path("/addUser/{username}/{password}")
	@Consumes(MediaType.TEXT_PLAIN)
	public String addUser(@PathParam("username") String username, @PathParam("password") String password) {
		UserDAO uDAO = new UserDAO();
		Users user = new Users(username, password);
		uDAO.persist(user);
		return "Added to database";
	}

	@GET
	@Path("getCountyCouncils/{username}/{password}")
	@Produces(MediaType.TEXT_PLAIN)
	public String getCountyCouncils(@PathParam("username") String username, @PathParam("password") String password) {
		String names = "";
		UserDAO uDAO = new UserDAO();
		Users user = uDAO.getUserByUsername(username);
		if (user.getPassword().equalsIgnoreCase(password)) {
			CountyCouncilDAO cDAO = new CountyCouncilDAO();
			List<CountyCouncil> cc = cDAO.getAllCountyCouncil();
			for (int x = 0; x < cc.size(); x++) {
				String n = cc.get(x).getName();
				names = names + n + "\n";
			}
			return names;
		} else {
			return "Invalid Details";
		}
	}
	
	@GET
	@Path("getCountyCouncilParks/{countyCouncil}/{username}/{password}")
	@Produces(MediaType.TEXT_PLAIN)
	public String getCountyCouncilParks(@PathParam("countyCouncil") String countyCouncil, @PathParam("username") String username,@PathParam("password") String password) {
		String parks = "";
		UserDAO uDAO = new UserDAO();
		Users user = uDAO.getUserByUsername(username);
		if (user.getPassword().equalsIgnoreCase(password)) {
			CountyCouncilDAO cDAO = new CountyCouncilDAO();
			CountyCouncil cc = cDAO.getCountyCouncilByName(countyCouncil);
			List<Park> p = cc.getParks();
			for (int x = 0; x < p.size(); x++) {
				String n = p.get(x).getName();
				parks = parks + n + "\n";
			}
			return parks;
		} else {
			return "Invalid Details";
		}
	}
	
	@GET
	@Path("getPark/{park}/{username}/{password}")
	@Produces(MediaType.TEXT_PLAIN)
	public String getPark(@PathParam("park") String park, @PathParam("username") String username,@PathParam("password") String password) {
		String time = "";
		String address = "";
		UserDAO uDAO = new UserDAO();
		Users user = uDAO.getUserByUsername(username);
		if (user.getPassword().equalsIgnoreCase(password)) {
			ParkDAO pDAO = new ParkDAO();
			Park p = pDAO.getParkByName(park);
			address = p.getAddress();
			time = p.getOpenTimes();
			return address +  "\n" + time;
		} else {
			return "Invalid Details";
		}
	}
	
	@POST
    @Path("/addPark/{countyCouncil}/{name}/{address}/{time}/{username}/{password}")
	@Consumes(MediaType.TEXT_PLAIN)
    public String addPark(@PathParam("countyCouncil") String countyCouncil,@PathParam("name") String name,@PathParam("address") String address,@PathParam("time") String time, @PathParam("username") String username,@PathParam("password") String password){
		UserDAO uDAO = new UserDAO();
		Users user = uDAO.getUserByUsername(username);
		if (user.getPassword().equalsIgnoreCase(password) && user.getUsername().equalsIgnoreCase("ADMIN")) {
		ParkDAO pDAO = new ParkDAO();
		Park p = new Park(name,address,time);
		pDAO.persist(p);
		CountyCouncilDAO ccDAO = new CountyCouncilDAO();
		CountyCouncil c = ccDAO.getCountyCouncilByName(countyCouncil);
		c.addPark(p);
		ccDAO.merge(c);
		return "Park Added";
		}else {
			return "Invalid Details";
		}
	}
	
	@POST
    @Path("/editName/{park}/{name}/{username}/{password}")
	@Consumes(MediaType.TEXT_PLAIN)
    public String editName(@PathParam("park") String park,@PathParam("name") String name, @PathParam("username") String username,@PathParam("password") String password){
		UserDAO uDAO = new UserDAO();
		Users user = uDAO.getUserByUsername(username);
		if (user.getPassword().equalsIgnoreCase(password) && user.getUsername().equalsIgnoreCase("ADMIN")) {
			ParkDAO pDAO = new ParkDAO();
			Park p = pDAO.getParkByName(park);
			p.setName(name);
			pDAO.merge(p);
		return "Name Updated";
		}else {
			return "Invalid Details";
		}
	}
	
	@POST
    @Path("/editAddresss/{park}/{address}/{username}/{password}")
	@Consumes(MediaType.TEXT_PLAIN)
    public String editAddresss(@PathParam("park") String park,@PathParam("address") String address, @PathParam("username") String username,@PathParam("password") String password){
		UserDAO uDAO = new UserDAO();
		Users user = uDAO.getUserByUsername(username);
		if (user.getPassword().equalsIgnoreCase(password) && user.getUsername().equalsIgnoreCase("ADMIN")) {
			ParkDAO pDAO = new ParkDAO();
			Park p = pDAO.getParkByName(park);
			p.setAddress(address);
			pDAO.merge(p);
		return "Address Updated";
		}else {
			return "Invalid Details";
		}
	}
	
	@POST
    @Path("/editTimes/{park}/{time}/{username}/{password}")
	@Consumes(MediaType.TEXT_PLAIN)
    public String editTimes(@PathParam("park") String park,@PathParam("time") String time, @PathParam("username") String username,@PathParam("password") String password){
		UserDAO uDAO = new UserDAO();
		Users user = uDAO.getUserByUsername(username);
		if (user.getPassword().equalsIgnoreCase(password) && user.getUsername().equalsIgnoreCase("ADMIN")) {
			ParkDAO pDAO = new ParkDAO();
			Park p = pDAO.getParkByName(park);
			p.setOpenTimes(time);
			pDAO.merge(p);
		return "Times Updated";
		}else {
			return "Invalid Details";
		}
	}
	
	@DELETE
    @Path("/removePark/{countyCouncil}/{name}/{username}/{password}")
	@Consumes(MediaType.TEXT_PLAIN)
    public String removePark(@PathParam("countyCouncil") String countyCouncil,@PathParam("name") String name, @PathParam("username") String username,@PathParam("password") String password){
		UserDAO uDAO = new UserDAO();
		Users user = uDAO.getUserByUsername(username);
		if (user.getPassword().equalsIgnoreCase(password) && user.getUsername().equalsIgnoreCase("ADMIN")) {
		ParkDAO pDAO = new ParkDAO();
		CountyCouncilDAO ccDAO = new CountyCouncilDAO();
		Park p = pDAO.getParkByName(name);
		pDAO.remove(p);
		CountyCouncil c = ccDAO.getCountyCouncilByName(countyCouncil);
		c.removcPark(p);
		ccDAO.merge(c);
		return "Park Removed";
		}else {
			return "Invalid Details";
		}
	}
	
	

}
