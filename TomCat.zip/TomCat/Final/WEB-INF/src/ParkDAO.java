
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class ParkDAO {
	
	protected static EntityManagerFactory emf = 
			Persistence.createEntityManagerFactory("jpaPU"); 	
	
	public ParkDAO() {
		
	}
	
	public void persist(Park park) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(park);
		em.getTransaction().commit();
		em.close();
	}
	
	public void remove(Park park) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.remove(em.merge(park));
		em.getTransaction().commit();
		em.close();
	}
	
	public Park merge(Park park) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Park updatedItem = em.merge(park);
		em.getTransaction().commit();
		em.close();
		return updatedItem;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Park> getAllParks() {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<Park> usersFromDB = new ArrayList<Park>();
		usersFromDB = em.createNamedQuery("Park.findAll").getResultList();
		em.getTransaction().commit();
		em.close();
		return usersFromDB;
	}
	
	@SuppressWarnings("unchecked")
	public Park getParkByName(String name){
		EntityManager em = emf.createEntityManager();
		List<Park> Parks = (List<Park>) 
				em.createNamedQuery("Park.findByName").
				setParameter("name", name).getResultList();
		em.close();
		Park park = new Park();
		for(Park p: Parks) {
			park = p;
		}
		return park;
		}
}