import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

public class ReadParks {
	
	ReadParks(){
		try {
			populate();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

    public static void populate() throws
            IOException, ParserConfigurationException, SAXException {
    	
    	List<Park> parks = new ArrayList<>();

        File xmlFile = new File("PlayAreas.xml");
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.parse(xmlFile);

        NodeList playAreas = doc.getElementsByTagName("Play_Areas");
        
        

        for (int i = 0; i < playAreas.getLength(); i++) {

            Node playArea = playAreas.item(i);
            String address = "";

            if (playArea.getNodeType() == Node.ELEMENT_NODE) {

                Element elem = (Element) playArea;

                Node name = elem.getElementsByTagName("Name").item(0);
                String fname = name.getTextContent();
                Node addres1 = elem.getElementsByTagName("Address1").item(0);
                String faddres1 = addres1.getTextContent();
                Node addres2 = elem.getElementsByTagName("Address2").item(0);
                String faddres2 = addres2.getTextContent();
                Node addres3 = elem.getElementsByTagName("Address3").item(0);
                String faddres3 = addres3.getTextContent();
                address = faddres1 + " " + faddres2 + " " + faddres3;
                Node hours = elem.getElementsByTagName("Opening_Hours").item(0);
                String fhours = hours.getTextContent();
                Park park = new Park(fname,address,fhours);
                ParkDAO pDAO = new ParkDAO();
				pDAO.persist(park);
				parks.add(park);

                
            }
        }
        
        CountyCouncil cc = new CountyCouncil("Fingal County Council",parks);
		CountyCouncilDAO ccDAO = new CountyCouncilDAO();
		ccDAO.persist(cc);
    }
}