import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CountyCouncilDAO {
	
	protected static EntityManagerFactory emf = 
			Persistence.createEntityManagerFactory("jpaPU"); 	
	
	public CountyCouncilDAO() {
		
	}
	
	public void persist(CountyCouncil cc) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(cc);
		em.getTransaction().commit();
		em.close();
	}
	
	
	public void remove(CountyCouncil cc) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.remove(em.merge(cc));
		em.getTransaction().commit();
		em.close();
	}
	
	public CountyCouncil merge(CountyCouncil cc) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		CountyCouncil updatedOrder = em.merge(cc);
		em.getTransaction().commit();
		em.close();
		return updatedOrder;
	}
	
	@SuppressWarnings("unchecked")
	public List<CountyCouncil> getAllCountyCouncil() {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<CountyCouncil> usersFromDB = new ArrayList<CountyCouncil>();
		usersFromDB = em.createNamedQuery("CountyCouncil.findAll").getResultList();
		em.getTransaction().commit();
		em.close();
		return usersFromDB;
	}
	
	@SuppressWarnings("unchecked")
	public CountyCouncil getCountyCouncilByName(String name){
		EntityManager em = emf.createEntityManager();
		List<CountyCouncil> CountyCouncils = (List<CountyCouncil>) 
				em.createNamedQuery("CountyCouncil.findByName").
				setParameter("name", name).getResultList();
		em.close();
		CountyCouncil countyCouncil = new CountyCouncil();
		for(CountyCouncil c: CountyCouncils) {
			countyCouncil = c;
		}
		return countyCouncil;
		}

}
