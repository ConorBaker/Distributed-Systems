import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Jsoup2 {
	
	public Jsoup2() {
		populate();
	}

	public void populate() {
		List<Park> ccp = new ArrayList<>();
		try {
			Document doc;

			doc = Jsoup.connect("https://www.dlrcoco.ie/en/parks-outdoors/playgrounds").get();
			String parkNames = "";
			Elements allSpans = doc.getElementsByTag("div");
			for (Element h2 : allSpans) {
				if (h2.attr("property").equalsIgnoreCase("content:encoded")) {
					parkNames = h2.text();
				}
			}
			ArrayList<String> words = new ArrayList<>(Arrays.asList(parkNames.split(" ")));
			ArrayList<String> parks = new ArrayList<String>();
			ArrayList<String> firstNames = new ArrayList<String>();
			ArrayList<String> fullNames = new ArrayList<String>();
			for (int x = 0; x < words.size(); x++) {
				if (words.get(x).equals("Park") || words.get(x).equals("Park,")) {
					String name = words.get(x - 1) + "-" + words.get(x);
					String name2 = "";
					firstNames.add(words.get(x - 1));
					String fullName = words.get(x - 1) + " " + words.get(x);
					fullNames.add(fullName);
					for (int z = 0; z < name.length(); z++) {
						char c = name.charAt(z);
						if (Character.toString(c).equals("\'") || Character.toString(c).equals(",")) {
						} else {
							name2 = name2 + Character.toString(c);
						}
					}
					parks.add(name2);
				}
			}
			for (int u = 0; u < parks.size(); u++) {
				Park park = new Park();
				if (parks.get(u).equals("Peoples-Park") || parks.get(u).equals("Cabinteely-Park")
						|| parks.get(u).equals("Shanganagh-Park")) {
					try {
						String link = parks.get(u);
						doc = Jsoup.connect("https://www.dlrcoco.ie/en/parks/" + link).get();
						// Get all "<span>" tags. Returned in an Elements collection object
						Elements divs = doc.getElementsByTag("div");
						String data = "";
						String openTimes = "";
						String address = "";
						for (Element div : divs) {
							if (div.attr("class").equalsIgnoreCase(
									"entity entity-field-collection-item field-collection-item-field-opening-hours clearfix")) {
								openTimes = openTimes + div.text() + " ";
							}
						}

						for (Element div : divs) {
							if (div.attr("class").equalsIgnoreCase(
									"field field-name-field-address field-type-text-long field-label-above")) {
								address = address + div.text() + " ";
							}
						}
						park.setName(fullNames.get(u));
						park.setAddress(address);
						if (openTimes != "") {
							park.setOpenTimes(openTimes);
						}

		
						 ParkDAO pDAO = new ParkDAO();
						 pDAO.persist(park);
						 ccp.add(park);
						 

					} catch (IOException e) {
						e.printStackTrace();
					}
				} else if (parks.get(u).equals("Marlay-Park")) {
					try {
						String link = parks.get(u);
						doc = Jsoup.connect("https://www.dlrcoco.ie/en/parks-outdoors/parks/" + link).get();
						// Get all "<span>" tags. Returned in an Elements collection object
						Elements divs = doc.getElementsByTag("div");
						String name = "";
						String openTimes = "";
						String address = "";
						int count = 0;
						for (Element div : divs) {
							if (div.attr("class").equalsIgnoreCase(
									"field field-name-field-information-description field-type-text-long field-label-hidden")) {
								if (count == 0) {
									openTimes = div.text();
								} else if (count == 1) {
									address = div.text();
								}
								count++;
							}
						}
						String n = parks.get(u);
						for (int i = 0; i < n.length(); i++) {
							char c = n.charAt(i);
							if (Character.toString(c).equals("-")) {
								name += " ";
							} else {
								name += Character.toString(c);
							}

						}
						String cleanOT = "";
						
						String[] spName = name.split(" ");
						String fn = spName[0];
						String[] split = openTimes.split(" ");
						for(int i = 0; i < split.length; i++) {
							if(split[i].equalsIgnoreCase(fn)){
								i = split.length -1;
							}
							cleanOT = cleanOT + split[i] + " ";
						}
						
						park.setName(name);
						park.setAddress(address);
						park.setOpenTimes(cleanOT);
						
					
						
						ParkDAO pDAO = new ParkDAO(); 
						pDAO.persist(park); 
						ccp.add(park);
					
					} catch (IOException e) {
						e.printStackTrace();
					}

				} else if (parks.get(u).equals("Blackrock-Park")) {

					try {
						String link = parks.get(u);
						doc = Jsoup.connect("https://www.dlrcoco.ie/en/" + link).get();
						// Get all "<span>" tags. Returned in an Elements collection object
						Elements divs = doc.getElementsByTag("div");
						String name = "";
						String address = "";
						int count = 0;
						for (Element div : divs) {
							if (div.attr("class").equalsIgnoreCase("field-item even")) {
								if (count == 2) {
									address = div.text();
								}
								count++;
							}
						}
						String n = parks.get(u);
						for (int i = 0; i < n.length(); i++) {
							char c = n.charAt(i);
							if (Character.toString(c).equals("-")) {
								name += " ";
							} else {
								name += Character.toString(c);
							}

						}
						park.setName(name);
						park.setAddress(address);

						 ParkDAO pDAO = new ParkDAO();
						 pDAO.persist(park); 
						 ccp.add(park);
						
					} catch (IOException e) {
						e.printStackTrace();
					}

				} else {
					String n = parks.get(u);
					String name = "";
					for (int i = 0; i < n.length(); i++) {
						char c = n.charAt(i);
						if (Character.toString(c).equals("-")) {
							name += " ";
						} else {
							name += Character.toString(c);
						}
					}
					park.setName(name);
					 ParkDAO pDAO = new ParkDAO(); 
					 pDAO.persist(park); 
					 ccp.add(park);
					 
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		
		 CountyCouncil cc = new CountyCouncil("Dun Laoghaire Rathdown County Council",ccp);
		 CountyCouncilDAO ccDAO = new CountyCouncilDAO(); 
		 ccDAO.persist(cc);
		 
		System.out.println("Parks Added Succsefully");
	}

}
