
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;


@NamedQueries({
@NamedQuery(name="Park.findAll", query="select o from Park o"), 
@NamedQuery(name = "Park.findByName", query = "select o from Park o where o.name=:name"),
})
@Entity

public class Park {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	String name;
	@Column(length=100000)
	String address;
	@Column(length=100000)
	String openTimes;
	
	public Park(String name, String address, String openTimes) {
		this.name = name;
		this.address = address;
		this.openTimes = openTimes;
	}
	
	public Park() {
		
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the openTimes
	 */
	public String getOpenTimes() {
		return openTimes;
	}

	/**
	 * @param openTimes the openTimes to set
	 */
	public void setOpenTimes(String openTimes) {
		this.openTimes = openTimes;
	}
	
	

	
	
}
