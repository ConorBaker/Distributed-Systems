
import java.io.IOException;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class JSoup {

	public static void main(String[] args) {
		
		Users user = new Users("ADMIN","PASSWORD");
		UserDAO uDAO = new UserDAO();
		uDAO.persist(user);
		
		ReadParks rp = new ReadParks();
		Jsoup2 jp2 = new Jsoup2();
	
		Document doc;
		List<Park> parks = new ArrayList<>();
		for (int p = 0; p < 4; p++) {
			try {
				doc = Jsoup.connect("https://www.dublincity.ie/residential/parks/dublin-city-parks/visit-park?keys=&amp%3Bfacilities=All&amp%3Bpage=4&facilities=All&page=" + p).get();
				
				// Get all "<span>" tags. Returned in an Elements collection object
				Elements allh2 = doc.getElementsByTag("h2");
				String name = "";
				String append = "";
				 
				// Go through the collection of tags assigning each one to an Element instance
				for (Element h2 : allh2) {
					name = "";
					append = "";
					// check the attribute of each one to see if it's equal to "underline"
					if (h2.attr("property").equalsIgnoreCase("name")) {
						Park park = new Park();
						name = h2.text();
						park.setName(name);
						for (int x = 0; x < name.length(); x++) {
							char c = name.charAt(x);
							if (Character.toString(c).equals("\'")){
							}
							else if (Character.toString(c).equals(" ") || Character.toString(c).equals("/")) {
								append += "-";
							} else {
								append += Character.toString(c);
							}
							try {
								doc = Jsoup.connect(
										"https://www.dublincity.ie/residential/parks/dublin-city-parks/visit-park" + "/"
												+ append)
										.get();
								// Get all "<span>" tags. Returned in an Elements collection object
								Elements tables = doc.getElementsByTag("table");
								for (Element table : tables) {
									if (!table.attr("class").equalsIgnoreCase("opening-times__week")) {
										String openings = "";
										Elements rows = table.select("tr");
										for (int i = 0; i < rows.size(); i++) {
											Element row = rows.get(i);
											openings = openings + row.text() + " " ;
										}
										park.setOpenTimes(openings);
									}
								}
								
								
								Elements as = doc.getElementsByTag("a");
								for (Element a : as) {
									if (a.attr("class").equalsIgnoreCase("full__top__location-link location__top__location-link")) {
										park.setAddress(a.text());
										}
								}

							} catch (IOException e) {
								e.printStackTrace();
							}
							// System.out.println(append);
						}
						
						ParkDAO pDAO = new ParkDAO();
						pDAO.persist(park);
						parks.add(park);
					}

				}
				

			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		CountyCouncil cc = new CountyCouncil("Dublin City Council",parks);
		CountyCouncilDAO ccDAO = new CountyCouncilDAO();
		ccDAO.persist(cc);
		System.out.println("Parks Added Succsefully");

		/*
		  try { doc =
		  Jsoup.connect("https://www.dlrcoco.ie/en/parks-outdoors/playgrounds").get();
		  
		  // Get all "<span>" tags. Returned in an Elements collection object Elements
		  Elements allSpans = doc.getElementsByTag("div");
		 
		  // Go through the collection of tags assigning each one to an Element
		  for (Element h2 : allSpans) { // check the attribute of each one to
			  if(h2.attr("property").equalsIgnoreCase("content:encoded")) { // If it is,
				  System.out.println(h2.text()); }
		  
		  }
		  
		  } catch (IOException e) { e.printStackTrace(); }
		 */
	}
	
}
